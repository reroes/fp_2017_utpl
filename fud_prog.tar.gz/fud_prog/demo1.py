"""
	nombre: Rene
	tema: uso de for
"""

suma = 0
for i in range(0,10):
	suma = suma + i

# print suma
cadena = "La suma es %d" % (suma)
print(cadena)