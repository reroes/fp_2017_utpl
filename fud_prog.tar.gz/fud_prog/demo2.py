"""
	nombre: Rene
	tema: uso de for
"""

nombre_ciudad = raw_input("Ingrese el nombre de la ciudad: \n")

cadena = "El nombre de la ciudad es %s" % (nombre_ciudad)
print(cadena)
